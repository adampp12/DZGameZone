
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyBFNyQ9DyMLAqkWMeBpAdoW-28ecR0BqrA",
  authDomain: "dzgamezone-9e3ca.firebaseapp.com",
  projectId: "dzgamezone-9e3ca",
  storageBucket: "dzgamezone-9e3ca.firebasestorage.app",
  messagingSenderId: "992589091735",
  appId: "1:992589091735:web:5caf0df87a676626876ad2",
  measurementId: "G-RQRN8CRDMV"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

window.signup = function() {
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    createUserWithEmailAndPassword(auth, email, password)
        .then((userCredential) => alert("تم إنشاء الحساب بنجاح"))
        .catch((error) => alert("خطأ: " + error.message));
}

window.login = function() {
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    signInWithEmailAndPassword(auth, email, password)
        .then((userCredential) => document.getElementById("login-section").style.display = "none")
        .then(() => document.getElementById("games-section").style.display = "block")
        .catch((error) => alert("خطأ: " + error.message));
}

onAuthStateChanged(auth, (user) => {
  if (user) {
    document.getElementById("user-info").innerText = "مرحبًا، " + user.email;
    document.getElementById("login-section").style.display = "none";
    document.getElementById("games-section").style.display = "block";
  }
});

window.showSection = function(type) {
    document.querySelectorAll('.games').forEach(div => div.style.display = 'none');
    document.getElementById(type).style.display = 'block';
}
